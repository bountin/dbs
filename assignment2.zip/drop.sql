
DROP TABLE bergefahrzeug;
DROP TABLE loeschfahrzeug;

DROP TABLE wettkampf_teilnahme;
DROP TABLE wettkampf;
DROP TABLE pers_wktruppe;
DROP TABLE wettkampftruppe;

DROP TABLE bericht;
DROP TABLE einsatz;
DROP TABLE ereignis;
DROP TABLE fahrzeug;
DROP TABLE fahrzeug_modell;

ALTER TABLE person DROP mannschaft;
ALTER TABLE mannschaft DROP leiter;

DROP TABLE mannschaft;
DROP TABLE person;
DROP TABLE dienstgrad;
