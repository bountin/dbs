DROP TRIGGER bericht_verfasser_constraints ON bericht;
DROP TRIGGER einsatz_distinct ON einsatz;

DROP FUNCTION bericht_verfasser_constraints();
DROP FUNCTION einsatz_distinct();

DROP FUNCTION f_bonus(int);
DROP FUNCTION p_erhoehe_dienstgrad(int);
